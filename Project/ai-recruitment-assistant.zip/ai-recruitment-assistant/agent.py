"""Core agent: LLM-driven tool-calling loop (ReAct style).

The agent receives a *goal* in natural language, then repeatedly
  1. asks the LLM what to do next (reasoning),
  2. executes the tool(s) the LLM chose (acting),
  3. feeds the observation back,
until the LLM answers without calling a tool. No fixed script decides the order of steps.
Conversation memory is persisted in SQLite and replayed on each run.
"""
import json
import re
from pathlib import Path

import config
from llm import get_llm
from tools import database as db
from tools.email_tool import fetch_applicant_emails
from tools.knowledge_tool import search_knowledge
from tools.parser_tool import extract_text_from_resume

SYSTEM_PROMPT = """You are an autonomous HR Recruitment Agent. You help a recruiter screen job applicants.

You have tools. Decide yourself which to call and in what order. Typical workflow for "process new applications":
  1. fetch_new_applications            -> list of new emails (+ attachment paths)
  2. search_knowledge                  -> retrieve the company hiring rubric (do this once before scoring)
  3. for EACH email with a resume: parse_resume -> evaluate_candidate -> save_candidate
     (use skip_email for emails with no usable resume)
  4. get_leaderboard                   -> rank everyone and report the result
For questions about candidates ("who are the top 3?", "why was X rejected?") use get_leaderboard / get_candidate_details.

Rules:
- Never invent candidates or scores; only report what tools returned.
- If a tool returns an error, adapt (skip that file, report it) and continue with the rest.
- Process every new application before answering. Finish with a short summary for the recruiter."""

TOOLS = [
    {"type": "function", "function": {"name": "fetch_new_applications",
     "description": "Fetch new, not-yet-processed application emails (IMAP inbox or local folder) and uploaded resumes. Saves attachments and returns source_id, sender, subject and attachment paths.",
     "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "parse_resume",
     "description": "Extract text from a resume file (PDF/DOCX/TXT). Returns a preview and length; the full text is cached for evaluate_candidate.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "search_knowledge",
     "description": "RAG: search the company knowledge base (hiring rubric, interview guidelines) and return the most relevant passages.",
     "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "k": {"type": "integer"}}, "required": ["query"]}}},
    {"type": "function", "function": {"name": "evaluate_candidate",
     "description": "Score a parsed resume against the job description and the retrieved hiring rubric using the LLM. Returns sub-scores, total score (0-100), strengths, weaknesses, missing skills and justification. Does not save.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "source_id": {"type": "string"},
                    "sender": {"type": "string"}}, "required": ["path", "source_id"]}}},
    {"type": "function", "function": {"name": "save_candidate",
     "description": "Persist an evaluated candidate to the database and mark the email as processed (prevents duplicates).",
     "parameters": {"type": "object", "properties": {"source_id": {"type": "string"}}, "required": ["source_id"]}}},
    {"type": "function", "function": {"name": "skip_email",
     "description": "Mark an email without a usable resume as processed so it is not fetched again.",
     "parameters": {"type": "object", "properties": {"source_id": {"type": "string"}, "reason": {"type": "string"}}, "required": ["source_id"]}}},
    {"type": "function", "function": {"name": "get_leaderboard",
     "description": "Return candidates ranked by score (highest first), optionally limited to top N.",
     "parameters": {"type": "object", "properties": {"limit": {"type": "integer"}}}}},
    {"type": "function", "function": {"name": "get_candidate_details",
     "description": "Get the full evaluation of one candidate by name (partial ok) or id.",
     "parameters": {"type": "object", "properties": {"name_or_id": {"type": "string"}}, "required": ["name_or_id"]}}},
]

WEIGHTS = {"skills_score": 50, "experience_score": 35, "education_score": 15}


class RecruitmentAgent:
    def __init__(self, job_title: str = "Software Engineer", job_description: str = "", llm=None):
        db.init_db()
        self.llm = llm or get_llm()
        self.job_title = job_title
        self.job_description = job_description or self._default_jd()
        self.resume_cache: dict[str, str] = {}
        self.pending: dict[str, dict] = {}

    def _default_jd(self) -> str:
        job = db.get_job(self.job_title)
        if job:
            return job["description"]
        sample = config.BASE_DIR / "assets" / "sample_jd.txt"
        return sample.read_text() if sample.exists() else self.job_title

    # ------------------------------------------------------------------ tools
    def _tool_fetch_new_applications(self, **_):
        return fetch_applicant_emails()

    def _tool_parse_resume(self, path, **_):
        text = extract_text_from_resume(path)
        self.resume_cache[path] = text
        return {"path": path, "characters": len(text), "preview": text[:300]}

    def _tool_search_knowledge(self, query, k=3, **_):
        return search_knowledge(query, k)

    def _tool_evaluate_candidate(self, path, source_id, sender="", **_):
        text = self.resume_cache.get(path) or extract_text_from_resume(path)
        rubric = "\n\n".join(r["text"] for r in
                             search_knowledge(f"{self.job_title} scoring weights skills experience education fairness", 3)["results"])
        prompt = f"""Evaluate the candidate against the job description using the company rubric.

HIRING RUBRIC (retrieved from knowledge base):
{rubric}

JOB DESCRIPTION ({self.job_title}):
{self.job_description}

RESUME:
{text[:9000]}

Return ONLY JSON with keys: name (string), email (string), skills_score (0-50), experience_score (0-35),
education_score (0-15), strengths (list of strings), weaknesses (list of strings),
missing_skills (list of strings), justification (2-3 sentences citing resume evidence)."""
        msgs = [{"role": "system", "content": "You are a fair, evidence-based technical recruiter. Output valid JSON only."},
                {"role": "user", "content": prompt}]
        ev = None
        for _ in range(2):  # one retry on malformed JSON
            raw = self.llm.chat(msgs, json_mode=True)["content"]
            try:
                ev = json.loads(re.search(r"\{.*\}", raw, re.S).group(0))
                break
            except Exception:
                msgs.append({"role": "user", "content": "That was not valid JSON. Return only the JSON object."})
        if ev is None:
            raise ValueError("LLM did not return valid JSON")
        for k, mx in WEIGHTS.items():  # clamp: LLM judges components, code computes the total
            ev[k] = max(0.0, min(float(ev.get(k, 0) or 0), mx))
        ev["score"] = round(sum(ev[k] for k in WEIGHTS), 1)
        ev["recommendation"] = ("Strong hire - technical interview" if ev["score"] >= 80 else
                                "Potential - phone screen" if ev["score"] >= 60 else
                                "Weak - keep on file" if ev["score"] >= 40 else "Reject")
        if not ev.get("email"):
            m = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", sender)
            ev["email"] = m.group(0) if m else ""
        ev.update(job_title=self.job_title, resume_path=path, source_id=source_id)
        self.pending[source_id] = ev
        return {k: ev[k] for k in ("name", "score", "skills_score", "experience_score", "education_score",
                                   "recommendation", "strengths", "weaknesses", "missing_skills", "justification")}

    def _tool_save_candidate(self, source_id, **_):
        if source_id not in self.pending:
            return {"error": "No evaluation pending for this source_id. Call evaluate_candidate first."}
        ev = self.pending.pop(source_id)
        res = db.save_candidate(ev)
        db.mark_processed(source_id, ev.get("email", ""), ev.get("job_title", ""))
        return {**res, "name": ev["name"], "score": ev["score"]}

    def _tool_skip_email(self, source_id, reason="", **_):
        db.mark_processed(source_id, "", f"skipped: {reason}")
        return {"skipped": True, "reason": reason}

    def _tool_get_leaderboard(self, limit=None, **_):
        rows = db.get_ranked_candidates(self.job_title, limit)
        return {"count": len(rows), "candidates": [
            {"rank": i, "id": r["id"], "name": r["name"], "email": r["email"], "score": r["score"],
             "recommendation": r["recommendation"]} for i, r in enumerate(rows, 1)]}

    def _tool_get_candidate_details(self, name_or_id, **_):
        r = db.get_candidate(name_or_id)
        return r or {"error": f"No candidate matching '{name_or_id}'"}

    # ------------------------------------------------------------------ loop
    def _execute(self, name, args):
        fn = getattr(self, f"_tool_{name}", None)
        if not fn:
            return {"error": f"Unknown tool {name}"}
        try:
            return fn(**args)
        except Exception as e:  # observation, not a crash: the agent can adapt
            return {"error": f"{type(e).__name__}: {e}"}

    def run(self, goal: str, on_step=None) -> dict:
        """Run the agent on a natural-language goal. Returns {'answer', 'trace'}."""
        memory = db.get_memory(10)
        messages = [{"role": "system", "content": SYSTEM_PROMPT + f"\n\nActive job: {self.job_title}"}]
        messages += memory + [{"role": "user", "content": goal}]
        trace = []
        answer = ""
        for step in range(config.MAX_AGENT_STEPS):
            msg = self.llm.chat(messages, tools=TOOLS)
            messages.append(msg)
            calls = msg.get("tool_calls")
            if not calls:
                answer = msg["content"]
                break
            for tc in calls:
                name = tc["function"]["name"]
                try:
                    args = json.loads(tc["function"]["arguments"] or "{}")
                except json.JSONDecodeError:
                    args = {}
                result = self._execute(name, args)
                entry = {"step": len(trace) + 1, "tool": name, "args": args, "result": result}
                trace.append(entry)
                if on_step:
                    on_step(entry)
                messages.append({"role": "tool", "tool_call_id": tc["id"],
                                 "content": json.dumps(result, default=str)[:4000]})
        else:
            answer = "Stopped: step limit reached before the task finished."
        db.add_memory("user", goal)
        db.add_memory("assistant", answer)
        return {"answer": answer, "trace": trace}
