"""LLM access layer.

`get_llm()` returns an object with  chat(messages, tools=None, json_mode=False) -> assistant message dict.
 * RealLLM : any OpenAI-compatible endpoint (OpenAI, Groq, Ollama, Together, ...)
 * MockLLM : deterministic offline stand-in so the whole pipeline can be demoed/tested without an API key.
"""
import json
import re
import uuid

import config


class RealLLM:
    name = "real"

    def __init__(self):
        from openai import OpenAI
        self.client = OpenAI(api_key=config.LLM_API_KEY or "none", base_url=config.LLM_BASE_URL)
        self.model = config.LLM_MODEL

    def chat(self, messages, tools=None, json_mode=False):
        kw = {"model": self.model, "messages": messages, "temperature": 0.1}
        if tools:
            kw["tools"] = tools
            kw["tool_choice"] = "auto"
        if json_mode:
            kw["response_format"] = {"type": "json_object"}
        m = self.client.chat.completions.create(**kw).choices[0].message
        out = {"role": "assistant", "content": m.content or ""}
        if m.tool_calls:
            out["tool_calls"] = [{"id": t.id, "type": "function",
                                  "function": {"name": t.function.name, "arguments": t.function.arguments}}
                                 for t in m.tool_calls]
        return out


# --------------------------------------------------------------------------- mock
SKILLS = ["python", "django", "flask", "fastapi", "sql", "postgresql", "docker", "kubernetes", "aws",
          "git", "rest", "api", "machine learning", "pytorch", "testing", "pytest", "javascript",
          "react", "linux", "ci/cd", "redis", "microservices"]


class MockLLM:
    name = "mock"

    def chat(self, messages, tools=None, json_mode=False):
        if json_mode:
            return {"role": "assistant", "content": json.dumps(self._evaluate(messages))}
        return self._act(messages)

    # --- evaluation by keyword overlap (stand-in for semantic judgement)
    def _evaluate(self, messages):
        text = messages[-1]["content"]
        jd = text.split("JOB DESCRIPTION", 1)[-1].split("\nRESUME:\n", 1)[0].lower()
        resume = text.split("\nRESUME:\n", 1)[-1]
        rl = resume.lower()
        wanted = [s for s in SKILLS if s in jd] or SKILLS[:8]
        have = [s for s in wanted if s in rl]
        missing = [s for s in wanted if s not in rl]
        yrs = [int(x) for x in re.findall(r"(\d+)\+?\s*years", rl)]
        years = max(yrs) if yrs else 0
        edu = 15 if re.search(r"(bs|bsc|b\.sc|bachelor|master)[^\n]*(computer|software|information tech|bscs|bsit|engineering)|bscs|bsit", rl) else 6
        relevance = min(1.0, 2 * len(have) / max(len(wanted), 1))  # experience only counts if relevant
        name = next((l.strip() for l in resume.splitlines() if l.strip() and len(l.split()) <= 4), "Unknown")
        em = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", resume)
        return {"name": name, "email": em.group(0) if em else "",
                "skills_score": round(50 * len(have) / max(len(wanted), 1), 1),
                "experience_score": round(min(35, years * 7) * relevance, 1),
                "education_score": edu,
                "strengths": [f"Covers required skills: {', '.join(have[:6]) or 'none'}",
                              f"About {years} years of stated experience"],
                "weaknesses": [f"Missing: {', '.join(missing[:5])}"] if missing else ["No major gaps"],
                "missing_skills": missing[:8],
                "justification": f"[mock] Matched {len(have)}/{len(wanted)} required skills; {years} yrs experience."}

    # --- scripted planner that reacts to tool results (stand-in for LLM reasoning)
    def _act(self, messages):
        last_user = max(i for i, m in enumerate(messages) if m["role"] == "user")
        goal = messages[last_user]["content"].lower()
        calls, results = [], []
        for m in messages[last_user + 1:]:
            if m["role"] == "assistant":
                for tc in m.get("tool_calls", []):
                    calls.append((tc["function"]["name"], json.loads(tc["function"]["arguments"] or "{}")))
            elif m["role"] == "tool":
                results.append(m["content"])
        done = {(n, json.dumps(a, sort_keys=True)) for n, a in calls}
        names = [n for n, _ in calls]

        def call(name, args):
            return {"role": "assistant", "content": "", "tool_calls": [{
                "id": "call_" + uuid.uuid4().hex[:8], "type": "function",
                "function": {"name": name, "arguments": json.dumps(args)}}]}

        def say(t):
            return {"role": "assistant", "content": t}

        if re.search(r"process|screen|fetch|new (applic|email)|evaluate", goal):
            if "fetch_new_applications" not in names:
                return call("fetch_new_applications", {})
            fetched = next(json.loads(r) for (n, _), r in zip(calls, results) if n == "fetch_new_applications")
            job = re.search(r"role[:\s]+([\w ]+?)(?:\.|$|\n)", messages[last_user]["content"])
            for e in fetched.get("emails", []):
                if not e["attachments"]:
                    a = {"source_id": e["source_id"], "reason": "no resume attached"}
                    if ("skip_email", json.dumps(a, sort_keys=True)) not in done:
                        return call("skip_email", a)
                    continue
                path = e["attachments"][0]
                for n, a in (("search_knowledge", {"query": "scoring rubric skills experience education"}),
                             ("parse_resume", {"path": path}),
                             ("evaluate_candidate", {"path": path, "source_id": e["source_id"], "sender": e["sender"]}),
                             ("save_candidate", {"source_id": e["source_id"]})):
                    if n == "search_knowledge" and "search_knowledge" in names:
                        continue
                    if (n, json.dumps(a, sort_keys=True)) not in done:
                        return call(n, a)
            if "get_leaderboard" not in names:
                return call("get_leaderboard", {"limit": 5})
            board = json.loads(results[names.index("get_leaderboard")])
            lines = [f"{i}. {c['name']} - {c['score']}/100" for i, c in enumerate(board.get("candidates", []), 1)]
            return say(f"[mock] Processed {fetched.get('count', 0)} new application(s). Current ranking:\n" + "\n".join(lines))
        if re.search(r"top|best|rank|who|compare|candidate", goal):
            if "get_leaderboard" not in names:
                m = re.search(r"top (\d+)", goal)
                return call("get_leaderboard", {"limit": int(m.group(1)) if m else 5})
            board = json.loads(results[names.index("get_leaderboard")])
            lines = [f"{i}. {c['name']} - {c['score']}/100" for i, c in enumerate(board.get("candidates", []), 1)]
            return say("[mock] " + ("\n".join(lines) or "No candidates evaluated yet."))
        return say("[mock] I can process new applications or answer questions about ranked candidates.")


def get_llm():
    if config.USE_MOCK_LLM or not config.LLM_API_KEY and not config.LLM_BASE_URL:
        return MockLLM()
    return RealLLM()
