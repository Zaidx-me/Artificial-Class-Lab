"""Component 8: Streamlit dashboard for the Agentic Recruitment & Screening System."""
import pandas as pd
import streamlit as st

import config
from agent import RecruitmentAgent
from tools import database as db
from tools.knowledge_tool import reload_index

st.set_page_config(page_title="AI Recruitment Agent", page_icon="🤖", layout="wide")
db.init_db()

# ---------------------------------------------------------------- sidebar
sb = st.sidebar
sb.title("🤖 Recruitment Agent")
agent_probe = RecruitmentAgent()
mode = "🧪 Mock LLM (offline demo)" if agent_probe.llm.name == "mock" else f"🧠 {config.LLM_MODEL}"
sb.caption(f"LLM: {mode}")

sb.subheader("Job")
jobs = db.get_jobs()
sample_jd = (config.BASE_DIR / "assets" / "sample_jd.txt").read_text()
job_title = sb.text_input("Job title", value="Software Engineer")
jd = sb.text_area("Job description", value=(db.get_job(job_title) or {}).get("description", sample_jd), height=200)
if sb.button("💾 Save job"):
    db.save_job(job_title, jd)
    sb.success("Job saved")

sb.subheader("Applications")
uploads = sb.file_uploader("Upload resumes (PDF/DOCX/TXT)", type=["pdf", "docx", "txt"], accept_multiple_files=True)
if uploads:
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for u in uploads:
        (config.UPLOAD_DIR / u.name).write_bytes(u.getvalue())
    sb.info(f"{len(uploads)} file(s) queued. Ask the agent to process them.")

sb.subheader("Session")
if sb.button("🗑️ Reset candidates & memory"):
    db.clear_candidates(); db.clear_memory(); st.session_state.pop("chat", None)
    sb.success("Cleared"); st.rerun()

db.save_job(job_title, jd)
agent = RecruitmentAgent(job_title, jd)

# ---------------------------------------------------------------- main
st.title("Agentic AI Recruitment & Applicant Ranking")
st.caption("Fetch emails → parse resumes → retrieve rubric (RAG) → LLM evaluation → score → rank. Decisions are made by the agent, step by step.")

tab_chat, tab_board, tab_kb = st.tabs(["💬 Agent", "🏆 Leaderboard", "📚 Knowledge base"])


def render_trace(trace):
    for t in trace:
        with st.expander(f"Step {t['step']}: `{t['tool']}`", expanded=False):
            st.json({"args": t["args"], "result": t["result"]}, expanded=False)


with tab_chat:
    st.session_state.setdefault("chat", [{"role": "assistant", "content":
        "Hi! Try **“Process all new applicant emails for the Software Engineer role.”** then ask "
        "**“Who are the top 3 candidates?”** or **“Why is Hina ranked below Ayesha?”**"}])
    c1, c2 = st.columns([1, 3])
    quick = c1.button("▶ Process new applications", use_container_width=True)
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
            if m.get("trace"):
                render_trace(m["trace"])
    prompt = st.chat_input("Give the agent a goal or ask about candidates…")
    if quick:
        prompt = f"Process all new applicant emails for the {job_title} role."
    if prompt:
        st.session_state.chat.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            with st.status("Agent working…", expanded=True) as status:
                def live(e):
                    st.write(f"**Step {e['step']}** → `{e['tool']}` {e['args'] if e['args'] else ''}")
                out = agent.run(prompt, on_step=live)
                status.update(label=f"Done in {len(out['trace'])} tool calls", state="complete")
            st.markdown(out["answer"])
        st.session_state.chat.append({"role": "assistant", "content": out["answer"], "trace": out["trace"]})
        st.rerun()

with tab_board:
    rows = db.get_ranked_candidates(job_title)
    if not rows:
        st.info("No candidates yet. Ask the agent to process applications.")
    else:
        df = pd.DataFrame(rows)
        df.insert(0, "rank", range(1, len(df) + 1))
        m1, m2, m3 = st.columns(3)
        m1.metric("Candidates", len(df)); m2.metric("Top score", df.score.max()); m3.metric("Average", round(df.score.mean(), 1))
        st.dataframe(df[["rank", "name", "email", "score", "skills_score", "experience_score", "education_score", "recommendation"]],
                     hide_index=True, use_container_width=True)
        st.bar_chart(df.set_index("name")[["skills_score", "experience_score", "education_score"]])
        for _, r in df.iterrows():
            with st.expander(f"#{r['rank']}  {r['name']} — {r['score']}/100 · {r['recommendation']}"):
                st.markdown(f"**Justification:** {r['justification']}")
                a, b, c = st.columns(3)
                a.markdown(f"**Strengths**\n\n{r['strengths']}")
                b.markdown(f"**Weaknesses**\n\n{r['weaknesses']}")
                c.markdown(f"**Missing skills**\n\n{r['missing_skills']}")
        st.download_button("⬇ Export CSV", df.to_csv(index=False), "candidates.csv", "text/csv")

with tab_kb:
    st.caption("Documents retrieved by the agent (RAG). Edit these files to change scoring policy.")
    for f in sorted(config.KNOWLEDGE_DIR.glob("*.md")):
        with st.expander(f.name):
            st.markdown(f.read_text())
    reload_index()
