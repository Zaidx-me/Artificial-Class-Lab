"""End-to-end test of the agent loop using the offline mock LLM (no API key needed)."""
import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["USE_MOCK_LLM"] = "1"
os.environ["DB_PATH"] = str(Path(tempfile.mkdtemp()) / "test.db")

from agent import RecruitmentAgent
from tools import database as db
from tools.knowledge_tool import search_knowledge


def test_rag():
    r = search_knowledge("how many points for experience", 2)["results"]
    assert r and "Relevant experience" in r[0]["text"]


def test_full_run_ranking_memory_dedup():
    a = RecruitmentAgent("Software Engineer")
    out = a.run("Process all new applicant emails for the Software Engineer role.")
    tools = [t["tool"] for t in out["trace"]]
    assert tools[0] == "fetch_new_applications" and tools.count("save_candidate") == 5
    assert "skip_email" in tools and tools[-1] == "get_leaderboard"
    ranked = db.get_ranked_candidates("Software Engineer")
    assert [c["name"] for c in ranked][0] == "Ayesha Khan"
    assert ranked[-1]["name"] == "Usman Tariq"
    assert all(0 <= c["score"] <= 100 for c in ranked)
    # second run: dedup memory -> nothing new gets scored again
    out2 = a.run("Process new applications again.")
    assert [t["tool"] for t in out2["trace"]].count("save_candidate") == 0
    assert len(db.get_ranked_candidates()) == 5
    # conversational memory + Q&A
    out3 = a.run("Who are the top 3 candidates?")
    assert out3["trace"][0]["tool"] == "get_leaderboard" and "Ayesha" in out3["answer"]
    assert len(db.get_memory(20)) == 6
