# Agentic AI Recruitment & Applicant Ranking System

Course: Artificial Intelligence (BSIT/BSCS 2024-2028) · Domain: HR / Recruitment Assistant

## Run it
```bash
pip install -r requirements.txt
cp .env.example .env            # add LLM_API_KEY (OpenAI/Groq) or point LLM_BASE_URL at Ollama
python scripts/make_samples.py  # sample CVs + simulated inbox (already included)
streamlit run app.py
```
No API key? It automatically uses an offline **Mock LLM** so you can demo the full pipeline. Tests: `python -m pytest -q tests`.
Real email: set `EMAIL_USER`/`EMAIL_PASS` (Gmail app password) and the IMAP tool reads unread mail instead of `assets/inbox/*.eml`.

## Rubric mapping
| # | Component | Where |
|---|-----------|-------|
| 1 | AI Agent | `agent.py` – `RecruitmentAgent.run()`: LLM picks the next tool each step (tool-calling loop, no fixed script) |
| 2 | LLM | `llm.py` – any OpenAI-compatible model (OpenAI, Groq, Ollama); used for planning *and* resume evaluation |
| 3 | Tools (≥3) | `fetch_new_applications` (IMAP/.eml), `parse_resume` (pypdf/python-docx), `save_candidate`/`get_leaderboard` (SQLite), `search_knowledge`, `evaluate_candidate`, `skip_email`, `get_candidate_details` |
| 4 | Agentic workflow | fetch → retrieve rubric → parse → evaluate → score → save → rank; errors become observations the agent adapts to |
| 5 | RAG | `tools/knowledge_tool.py` – chunks `knowledge/*.md`, TF-IDF cosine retrieval; top passages injected into every evaluation prompt |
| 6 | Memory | SQLite: `processed_emails` (no duplicate scoring), `candidates` (ranked cohorts persist), `chat_memory` (last turns replayed to the LLM) |
| 7 | Python | 100% Python |
| 8 | UI | `app.py` – Streamlit: agent chat with live step trace, leaderboard, charts, CSV export, knowledge viewer |

## Design notes (for the viva)
- **LLM judges, code computes.** The LLM returns sub-scores (skills /50, experience /35, education /15); Python clamps them and sums the total, so scores are bounded and consistent with `knowledge/hiring_rubric.md`.
- **Explainable:** every candidate has strengths, weaknesses, missing skills, justification and a hiring recommendation.
- **Fairness:** the rubric tells the LLM not to use name, gender, age or university prestige.
- **Idempotent:** re-running "process new applications" scores nothing twice.
- Limitations: scanned-image PDFs need OCR; the TF-IDF retriever is lexical (swap in embeddings for a larger knowledge base).

## Layout
```
app.py  agent.py  llm.py  config.py
tools/   email_tool.py  parser_tool.py  database.py  knowledge_tool.py
knowledge/  hiring_rubric.md  interview_guidelines.md
assets/  sample_jd.txt  resumes/  inbox/      scripts/make_samples.py     tests/
```
