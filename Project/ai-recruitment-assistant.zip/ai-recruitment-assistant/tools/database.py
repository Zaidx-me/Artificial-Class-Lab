"""Tool 3 + long-term memory: SQLite persistence (stdlib only).

Tables
  candidates        - evaluated applicants (score, justification, ...)
  processed_emails  - Message-IDs / file hashes already handled (de-duplication memory)
  chat_memory       - conversation history so the agent remembers earlier turns
  jobs              - job descriptions the recruiter has configured
"""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import config


@contextmanager
def _conn():
    Path(config.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(config.DB_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db():
    with _conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS candidates(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_title TEXT, name TEXT, email TEXT, score REAL,
            skills_score REAL, experience_score REAL, education_score REAL,
            strengths TEXT, weaknesses TEXT, missing_skills TEXT,
            justification TEXT, recommendation TEXT,
            resume_path TEXT, source_id TEXT UNIQUE,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS processed_emails(
            source_id TEXT PRIMARY KEY, sender TEXT, subject TEXT,
            processed_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS chat_memory(
            id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, content TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS jobs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT UNIQUE, description TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)


# ---------- candidates ----------
def save_candidate(data: dict) -> dict:
    """Insert/replace an evaluated candidate. Returns {'saved': True, 'id': ...}."""
    def lst(v):
        return "\n".join(f"- {x}" for x in v) if isinstance(v, list) else (v or "")
    with _conn() as c:
        c.execute("""INSERT OR REPLACE INTO candidates
            (job_title,name,email,score,skills_score,experience_score,education_score,
             strengths,weaknesses,missing_skills,justification,recommendation,resume_path,source_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("job_title", ""), data.get("name", "Unknown"), data.get("email", ""),
             float(data.get("score", 0) or 0),
             float(data.get("skills_score", 0) or 0),
             float(data.get("experience_score", 0) or 0),
             float(data.get("education_score", 0) or 0),
             lst(data.get("strengths")), lst(data.get("weaknesses")),
             lst(data.get("missing_skills")), data.get("justification", ""),
             data.get("recommendation", ""), data.get("resume_path", ""),
             data.get("source_id") or data.get("resume_path", "")))
        cid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    return {"saved": True, "id": cid}


def get_ranked_candidates(job_title: str | None = None, limit: int | None = None) -> list[dict]:
    q, args = "SELECT * FROM candidates", []
    if job_title:
        q += " WHERE job_title = ?"
        args.append(job_title)
    q += " ORDER BY score DESC, id ASC"
    if limit:
        q += " LIMIT ?"
        args.append(int(limit))
    with _conn() as c:
        return [dict(r) for r in c.execute(q, args).fetchall()]


def get_candidate(name_or_id) -> dict | None:
    with _conn() as c:
        if str(name_or_id).isdigit():
            r = c.execute("SELECT * FROM candidates WHERE id=?", (int(name_or_id),)).fetchone()
        else:
            r = c.execute("SELECT * FROM candidates WHERE lower(name) LIKE ? ORDER BY score DESC",
                          (f"%{str(name_or_id).lower()}%",)).fetchone()
        return dict(r) if r else None


def clear_candidates():
    with _conn() as c:
        c.execute("DELETE FROM candidates")
        c.execute("DELETE FROM processed_emails")


# ---------- de-duplication memory ----------
def is_processed(source_id: str) -> bool:
    with _conn() as c:
        return c.execute("SELECT 1 FROM processed_emails WHERE source_id=?", (source_id,)).fetchone() is not None


def mark_processed(source_id: str, sender: str = "", subject: str = ""):
    with _conn() as c:
        c.execute("INSERT OR IGNORE INTO processed_emails(source_id,sender,subject) VALUES (?,?,?)",
                  (source_id, sender, subject))


# ---------- conversation memory ----------
def add_memory(role: str, content: str):
    with _conn() as c:
        c.execute("INSERT INTO chat_memory(role,content) VALUES (?,?)", (role, content))


def get_memory(limit: int = 12) -> list[dict]:
    with _conn() as c:
        rows = c.execute("SELECT role,content FROM chat_memory ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]


def clear_memory():
    with _conn() as c:
        c.execute("DELETE FROM chat_memory")


# ---------- jobs ----------
def save_job(title: str, description: str):
    with _conn() as c:
        c.execute("INSERT OR REPLACE INTO jobs(title,description) VALUES (?,?)", (title, description))


def get_jobs() -> list[dict]:
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM jobs ORDER BY id DESC").fetchall()]


def get_job(title: str) -> dict | None:
    with _conn() as c:
        r = c.execute("SELECT * FROM jobs WHERE title=?", (title,)).fetchone()
        return dict(r) if r else None
