"""Tool 1: email fetcher.

Two sources, same output:
  * IMAP (real inbox) when EMAIL_USER / EMAIL_PASS are configured
  * a local folder of .eml files (assets/inbox) - handy for demos & viva without credentials
Already-processed messages (by Message-ID) are skipped -> memory against duplicates.
"""
import email
import hashlib
import imaplib
import re
from email import policy
from pathlib import Path

import config
from tools import database as db

ALLOWED = (".pdf", ".docx", ".txt")


def _save_attachments(msg, source_id: str) -> list[str]:
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    paths = []
    for part in msg.walk():
        fn = part.get_filename()
        if fn and fn.lower().endswith(ALLOWED):
            safe = re.sub(r"[^\w.\-]", "_", fn)
            tag = hashlib.md5(source_id.encode()).hexdigest()[:6]
            path = config.DOWNLOAD_DIR / f"{tag}_{safe}"
            path.write_bytes(part.get_payload(decode=True) or b"")
            paths.append(str(path))
    return paths


def _body(msg) -> str:
    try:
        part = msg.get_body(preferencelist=("plain",))
        return part.get_content() if part else ""
    except Exception:
        return ""


def _handle(msg, fallback_id: str) -> dict | None:
    source_id = (msg.get("Message-ID") or fallback_id).strip()
    if db.is_processed(source_id):
        return None
    return {"source_id": source_id, "sender": str(msg.get("From", "")),
            "subject": str(msg.get("Subject", "")), "body": _body(msg)[:1500],
            "attachments": _save_attachments(msg, source_id)}


def fetch_applicant_emails(limit: int = 20) -> dict:
    """Fetch NEW (not yet processed) application emails. Returns {'source', 'emails': [...]}."""
    emails = []
    if config.EMAIL_USER and config.EMAIL_PASS:
        source = "imap"
        mail = imaplib.IMAP4_SSL(config.IMAP_SERVER)
        mail.login(config.EMAIL_USER, config.EMAIL_PASS)
        mail.select("inbox")
        _, data = mail.search(None, "(UNSEEN)")
        for num in data[0].split()[:limit]:
            _, md = mail.fetch(num, "(RFC822)")
            msg = email.message_from_bytes(md[0][1], policy=policy.default)
            item = _handle(msg, f"imap-{num.decode()}")
            if item:
                emails.append(item)
        mail.logout()
    else:
        source = f"local folder {config.INBOX_DIR}"
        for f in sorted(Path(config.INBOX_DIR).glob("*.eml"))[:limit]:
            msg = email.message_from_bytes(f.read_bytes(), policy=policy.default)
            item = _handle(msg, f"file-{f.name}")
            if item:
                emails.append(item)
    # resumes uploaded via the UI are treated as applications too
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for f in sorted(config.UPLOAD_DIR.iterdir()):
        if f.suffix.lower() in ALLOWED:
            sid = "upload-" + hashlib.md5(f.read_bytes()).hexdigest()
            if not db.is_processed(sid):
                emails.append({"source_id": sid, "sender": "uploaded via dashboard", "subject": f.name,
                               "body": "", "attachments": [str(f)]})
    return {"source": source + " + uploads", "count": len(emails), "emails": emails}
